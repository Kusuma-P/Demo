package com.example.demo.operations;

import java.util.HashSet;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.demo.dto.StudentDto;
import com.example.demo.entities.Student;
import com.example.demo.repository.StudentRepository;

@Component
public class StudentOperations {

	@Autowired
	private StudentRepository repository;

	public Student fetchDetailsFromDb(int i) {
		Student student = repository.findByStudentId(i);
		if (null != student) {
			return student;
		}
		return student;
	}

	public List<Student> fetchAllDetails() {
		return repository.findAll(); 

	}

	/*
	 * public List<Student> addStudent(StudentDto studentDto) { Student student
	 * = fetchDetailsFromDb(studentDto.getStudentId()); if (null != student) {
	 * return fetchAllDetails(); } else { Student newStudent = new Student();
	 * newStudent.setStudentId(studentDto.getStudentId());
	 * newStudent.setStudentName(studentDto.getStudentName());
	 * newStudent.setStudenBranch(studentDto.getStudentBranch());
	 * repository.save(newStudent);
	 * 
	 * return fetchAllDetails();
	 * 
	 * } }
	 */

	public HashSet<Student> addStudent(StudentDto studentDto) {
		Student student = fetchDetailsFromDb(studentDto.getStudentId());
		HashSet<Student> studentList = new HashSet<>();
		if (null != student) {
			studentList.addAll(fetchAllDetails());
			student.setStudentName(studentDto.getStudentName());
			repository.save(student);

		} else {

			Student newStudent = new Student();
			newStudent.setStudentId(studentDto.getStudentId());
			newStudent.setStudentName(studentDto.getStudentName());
			newStudent.setStudenBranch(studentDto.getStudentBranch());
			repository.save(newStudent);
			studentList.addAll(fetchAllDetails());
		}
		return studentList;
	}

	public List<Student> removeStudent(int studentId) {
		Student student = fetchDetailsFromDb(studentId);
		if (null != student) {
			repository.delete(student);
			return fetchAllDetails();
		} else {

			return fetchAllDetails();

		}

	}
public Student updateStudent(StudentDto studentDto){
	Student student = repository.findByStudentId(studentDto.getStudentId());
	if (null != student) {
		student.setStudenBranch(studentDto.getStudentBranch());
		student.setStudentName(studentDto.getStudentName());
		return repository.save(student);
	}
		return student;
	}
	
}
