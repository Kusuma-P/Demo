package com.example.demo.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


@Entity
@SequenceGenerator(name="student_sequence",initialValue=100)
@Table(name = "student_table")
public class Student {

	@Id
	@Column(name = "ID")
    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="student_sequence")
	private int studentId;

	@Column(name = "Name", length = 30)
	private String studentName;

	@Column(name = "Branch", length = 3)
	private String studentBranch;

	public int getStudentId() {
		return studentId;
	}

	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public String getStudentBranch() {
		return studentBranch;
	}

	public void setStudenBranch(String studentBranch) {
		this.studentBranch = studentBranch;
	}

}
