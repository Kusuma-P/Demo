package com.example.demo.controller;

import java.util.HashSet;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.dto.StudentDto;
import com.example.demo.entities.Student;
import com.example.demo.operations.StudentOperations;

@Controller
@CrossOrigin
@RequestMapping("/students")
public class StudentController {

	@Autowired
	private StudentOperations studentOperation;

	@RequestMapping(value = "/findStudent", method = RequestMethod.POST)
	public ResponseEntity<String> fetchDetailsFromOperation(@RequestBody StudentDto student) {
		String message = "Student details found";
		String errorMessage = "No details found";
		Student fetchStudent = studentOperation.fetchDetailsFromDb(student.getStudentId());

		if (null != fetchStudent) {
			return new ResponseEntity<>(message, HttpStatus.OK);
		} else
			return new ResponseEntity<>(errorMessage, HttpStatus.BAD_REQUEST);
	}

	@RequestMapping(value = "/findAllStudents", method = RequestMethod.GET)
	public ResponseEntity<List<Student>> fetchAllDetails() {
		List<Student> list = studentOperation.fetchAllDetails();
		if (!list.isEmpty())
			return new ResponseEntity<>(list, HttpStatus.OK);
		else
			return new ResponseEntity<>(list, HttpStatus.BAD_REQUEST);

	}

	@RequestMapping(value = "/addStudent", method = RequestMethod.POST)
	public ResponseEntity<HashSet<Student>> fetchAllDetailsFromOperation(@RequestBody StudentDto student) {
		HashSet<Student> studentList = studentOperation.addStudent(student);
		if (!studentList.isEmpty()) {
			return new ResponseEntity<>(studentList, HttpStatus.OK);
		} else
			return new ResponseEntity<>(studentList, HttpStatus.BAD_REQUEST);

	}

	@RequestMapping(value = "/removeStudent", method = RequestMethod.DELETE)
	public ResponseEntity<List<Student>> removeStudentFromOperation(@RequestParam int studentId) {
		List<Student> list = studentOperation.removeStudent(studentId);
		if (!list.isEmpty()) {
			return new ResponseEntity<>(list, HttpStatus.OK);
		} else
			return new ResponseEntity<>(list, HttpStatus.BAD_REQUEST);

	}
	
	@RequestMapping(value="/updateStudent",method=RequestMethod.PUT)
	public ResponseEntity<Student> updateStudent(@RequestBody StudentDto studentDto){
		Student student=studentOperation.updateStudent(studentDto);
		if(null!=student)
		return new ResponseEntity<>(student,HttpStatus.OK);
		else
			return new ResponseEntity<>(student,HttpStatus.BAD_REQUEST);
		
	}

}
